import java.util.Scanner;

/* execution example: (user input underlined)
 * Enter a line: Welcome to the world of Java
 * Number of spaces: 5
 */

public class Ex45_CountingSpaces {
  public static void main(String[] args) {
    Scanner input;
    String s;
    int num_spaces;

    System.out.print("Enter a line: ");
    input = new Scanner(System.in);
    s = input.nextLine();
    num_spaces = 0;
    for (int i=0; i<s.length(); i++)
      if ( s.charAt(i) == ' ' ) num_spaces++;
    System.out.println("Number of spaces: " + num_spaces);
  }
}
