#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
  double A = 32.0/180*M_PI;

  // tan^-1 sin 32 cos 32
  fprintf(stdout,"%lf\n",atan(sin(A)*cos(A)));

  fprintf(stdout,"%lf\n",pow(exp(1.67)*pow(1.65,log(8)/log(20)),0.25));
  fprintf(stdout,"%lf\n",log(pow(21,log(35)))/log(7));
  fprintf(stdout,"%lf\n",exp(sqrt(log(4))+sqrt(log(5))));
}

