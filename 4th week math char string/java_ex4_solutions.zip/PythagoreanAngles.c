#include <stdio.h>
#include <math.h>

int main()
{
  const double ab = 4.0, ac = 3.0;
  double bc;
  double alpha, beta;

  bc = sqrt(ab*ab+ac*ac);
  alpha = acos((ac*ac-bc*bc-ab*ab)/(-2*bc*ab));
  beta  = acos((ab*ab-bc*bc-ac*ac)/(-2*bc*ac));

  fprintf(stdout,"alpha = %.2lf radians, %.1lf degrees\n",
      alpha, alpha/M_PI*180.0);
  fprintf(stdout,"beta = %.2lf radians, %.1lf degrees\n",
      beta, beta/M_PI*180.0);
}
