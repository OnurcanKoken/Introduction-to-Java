#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
  double x1, y1, x2, y2, x3, y3;
  double a, b, c;
  double A, B, C;

  // Prompt the user to enter three points
  fprintf(stdout,"Enter three points: ");
  fscanf(stdin,"%lf",&x1);
  fscanf(stdin,"%lf",&y1);
  fscanf(stdin,"%lf",&x2);
  fscanf(stdin,"%lf",&y2);
  fscanf(stdin,"%lf",&x3);
  fscanf(stdin,"%lf",&y3);

  // Compute three sides
  a = sqrt((x2-x3)*(x2-x3) + (y2-y3)*(y2-y3));
  b = sqrt((x1-x3)*(x1-x3) + (y1-y3)*(y1-y3));
  c = sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));

  // Compute three angles
  A = (acos((a*a-b*b-c*c)/(-2*b*c))/M_PI*180.0);
  B = (acos((b*b-a*a-c*c)/(-2*a*c))/M_PI*180.0);
  C = (acos((c*c-b*b-a*a)/(-2*a*b))/M_PI*180.0);

  // Display results
  fprintf(stdout,"The three angles are %lf %lf %lf\n",
      round(A*100)/100.0,
      round(B*100)/100.0,
      round(C*100)/100.0);
  fprintf(stdout,"The three angles are %.2lf %.2lf %.2lf\n",
      round(A),round(B),round(C));
}

