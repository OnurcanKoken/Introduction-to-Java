import java.util.Scanner;

public class ComputeAngles {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    double x1, y1, x2, y2, x3, y3;
    double a, b, c;
    double A, B, C;

    // Prompt the user to enter three points
    System.out.print("Enter three points: ");
    x1 = input.nextDouble();
    y1 = input.nextDouble();
    x2 = input.nextDouble();
    y2 = input.nextDouble();
    x3 = input.nextDouble();
    y3 = input.nextDouble();

    // Compute three sides
    a = Math.sqrt((x2-x3)*(x2-x3) + (y2-y3)*(y2-y3));
    b = Math.sqrt((x1-x3)*(x1-x3) + (y1-y3)*(y1-y3));
    c = Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));

    // Compute three angles
    A = Math.toDegrees(Math.acos((a*a-b*b-c*c)/(-2*b*c)));
    B = Math.toDegrees(Math.acos((b*b-a*a-c*c)/(-2*a*c)));
    C = Math.toDegrees(Math.acos((c*c-b*b-a*a)/(-2*a*b)));

    // Display results
    System.out.println("The three angles are " +
	Math.round(A*100)/100.0 + " " +
	Math.round(B*100)/100.0 + " " +
	Math.round(C*100)/100.0);
  }
}
