public class Ex43_math_exercises {
  public static void main(String[] args) {
    double A = Math.toRadians(32.0);

    // tan^-1 sin 32 cos 32
    System.out.println(Math.atan(Math.sin(A)*Math.cos(A)));

    System.out.println(Math.pow(Math.exp(1.67)*Math.pow(1.65,Math.log(8)/Math.log(20)),0.25));
    System.out.println(Math.log(Math.pow(21,Math.log(35)))/Math.log(7));
    System.out.println(Math.exp(Math.sqrt(Math.log(4))+Math.sqrt(Math.log(5))));
  }
}

