#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main()
{
  //const int low = -18, high = 9;
  // const does not work with switch, so use #define for constant definition
#define low	-18
#define high	9
  int countlow, counthigh;
  int r;

  // set a seed by the current time
  srand(time(NULL));

  // initialize found flags and found counts
  countlow = -1; counthigh = -1;
  for (int i=0; countlow<0 || counthigh<0 ; i++) {
    // generate a number 
    //r = (int)((double)low + Math.random()*(double)(high-low+1));	// wrong
    //r = low + (int)(Math.random()*(double)(high-low+1));
    r = low + rand()%(high-low+1);

    switch ( r ) {
      case low:
	fprintf(stdout,">> Found %d at %d\n", low, i);
	if ( countlow < 0 ) countlow = i;
	break;
      case high:
	fprintf(stdout,">> Found %d at %d\n", high, i);
	if ( counthigh < 0 ) counthigh = i;
	break;
    }
  }
  fprintf(stdout,"The first appearance of %d was at %d\n", low, countlow);
  fprintf(stdout,"The first appearance of %d was at %d\n", high, counthigh);
}
