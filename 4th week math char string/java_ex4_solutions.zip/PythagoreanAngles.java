public class PythagoreanAngles {
  public static void main(String[] args) {
    final double ab = 4.0, ac = 3.0;
    double bc;
    double alpha, beta;

    bc = Math.sqrt(ab*ab+ac*ac);
    alpha = Math.acos((ac*ac-bc*bc-ab*ab)/(-2*bc*ab));
    beta  = Math.acos((ab*ab-bc*bc-ac*ac)/(-2*bc*ac));

    System.out.printf("alpha = %.2f radians, %.1f degrees\n",
	alpha, Math.toDegrees(alpha));
    System.out.printf("beta = %.2f radians, %.1f degrees\n",
	beta, Math.toDegrees(beta));
  }
}
