public class Ex44_RandomNumberGen {
  public static void main(String[] args) {
    final int low = -18, high = 9;
    int countlow, counthigh;
    int r;

    // initialize found flags and found counts
    countlow = -1; counthigh = -1;
    for (int i=0; countlow<0 || counthigh<0 ; i++) {
      // generate a number 
      //r = (int)((double)low + Math.random()*(double)(high-low+1));	// wrong
      r = low + (int)(Math.random()*(double)(high-low+1));

      switch ( r ) {
	case low:
	  System.out.println(">> Found " + low + " at " + i);
	  if ( countlow < 0 ) countlow = i;
	  break;
	case high:
	  System.out.println(">> Found " + high + " at " + i);
	  if ( counthigh < 0 ) counthigh = i;
	  break;
      }
    }
    System.out.println("The first appearance of " + low + " was at " + countlow);
    System.out.println("The first appearance of " + high + " was at " + counthigh);
  }
}

