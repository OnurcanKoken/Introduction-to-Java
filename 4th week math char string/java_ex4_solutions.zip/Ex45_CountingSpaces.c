#include <stdio.h>

/* execution example: (user input underlined)
 * Enter a line: Welcome to the world of Java
 * Number of spaces: 5
 */

#define MAX_CHAR_LINE	1023
int main()
{
  char s[MAX_CHAR_LINE+1];
  int num_spaces;
  int i;

  fprintf(stdout,"Enter a line: ");
  fgets(s,MAX_CHAR_LINE,stdin);
  num_spaces = 0;
  for (i=0; i<MAX_CHAR_LINE; i++) {
    if ( s[i] == '\0' ) break;
    else if ( s[i] == ' ' ) num_spaces++;
  }
  fprintf(stdout,"Number of spaces: %d\n", num_spaces);
}
